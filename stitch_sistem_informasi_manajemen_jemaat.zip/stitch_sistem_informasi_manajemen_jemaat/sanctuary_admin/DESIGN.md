# Design System Specification: The Sacred Stewardship

This document defines the visual and interaction logic for the church congregation management platform. As designers, your goal is to transcend the "administrative database" feel. We are building a digital home for community data—one that feels as authoritative as a cathedral but as welcoming as a sanctuary.

## 1. Overview & Creative North Star: "The Digital Vestry"

The Creative North Star for this system is **"The Digital Vestry."** In traditional architecture, a vestry is a place of order, preparation, and quiet dignity. 

To achieve this, we move away from the "Bootstrap" look of rigid lines and heavy borders. Instead, we utilize **Editorial Layering**. We treat the screen like a high-end publication: expansive white space, intentional asymmetry in dashboard layouts, and a "No-Line" philosophy that relies on tonal shifts rather than ink to define space. The result is a system that feels premium, calm, and profoundly trustworthy.

---

## 2. Colors: Tonal Depth & The "No-Line" Rule

We lead with `primary` (#436088) to establish trust. However, the sophistication lies in how we layer the neutrals.

*   **The "No-Line" Rule:** You are strictly prohibited from using 1px solid borders to separate sections. Structure must be created through background shifts. For example, a sidebar using `surface-container-low` sits against a main content area of `surface`.
*   **Surface Hierarchy:** 
    *   **Level 0 (Base):** `surface` (#f9f9fe) - Use for the main background.
    *   **Level 1 (Sections):** `surface-container-low` (#f2f3fa) - Use for grouping secondary content areas.
    *   **Level 2 (Active Cards):** `surface-container-lowest` (#ffffff) - Use for the most important data points to make them "pop" naturally.
*   **The Glass Rule:** For floating modals or dropdowns, use `surface-container-lowest` with an 85% opacity and a `backdrop-filter: blur(12px)`. This creates a "frosted glass" effect that keeps the UI feeling airy.
*   **Signature Textures:** For primary action buttons or high-level stat cards, apply a subtle linear gradient from `primary_dim` (#37547b) to `primary` (#436088) at a 135-degree angle. This adds a "soul" to the color that flat hex codes lack.

---

## 3. Typography: Administrative Clarity meets Editorial Grace

We use a dual-font strategy to balance the human element with data density.

*   **Display & Headlines (Manrope):** This geometric sans-serif provides a modern, welcoming tone. Use `display-sm` for dashboard welcomes and `headline-sm` for section headers. Bold weights should be used sparingly to maintain an "editorial" feel.
*   **Body & Labels (Inter):** Chosen for its exceptional legibility at small sizes. All administrative data, table rows, and form labels must use Inter.
*   **Intentional Scale:** Use `label-sm` (#0.6875rem) in `on-surface-variant` for metadata. The high contrast between a `headline-lg` title and `body-sm` metadata creates a sophisticated, hierarchical depth.

---

## 4. Elevation & Depth: Tonal Layering

Traditional shadows are often "dirty." In this system, depth is biological and soft.

*   **The Layering Principle:** Instead of shadows, stack your surfaces. A card (`surface-container-lowest`) placed on a section background (`surface-container-low`) creates a natural lift.
*   **Ambient Shadows:** If an element must float (e.g., a "New Member" FAB), use a shadow tinted with the primary color: `rgba(67, 96, 136, 0.08)` with a 20px blur and 8px Y-offset. Never use pure black or grey for shadows.
*   **The Ghost Border:** If a boundary is required for accessibility (e.g., in a high-density table), use `outline-variant` at 15% opacity. It should be felt, not seen.

---

## 5. Components: Refined Utility

### Buttons
*   **Primary:** Gradient fill (`primary_dim` to `primary`), `xl` (0.75rem) roundedness. No border.
*   **Secondary:** `surface-container-high` background with `on-primary-container` text.
*   **Tertiary:** No background. Use `primary` text with an underline that only appears on hover.

### Statistics Cards
*   **Style:** Background `surface-container-lowest`. 
*   **Design:** Remove all borders. Use a 4px left-accent bar using the `tertiary` (#366769) color to denote growth or `primary` for general stats.
*   **Typography:** The "Big Number" should be `headline-lg` in `on-surface`.

### Data Tables & Lists
*   **The Rule:** No vertical or horizontal lines between rows.
*   **Spacing:** Increase row height to 64px. Use zebra-striping with `surface-container-low` on hover states only. 
*   **Alignment:** Numbers should be tabular-lining (Inter) for perfect vertical alignment in financial or census data.

### Input Fields
*   **Style:** Filled style using `surface-container-high`. 
*   **Indicator:** A 2px bottom-bar that animates from the center using `primary` on focus.
*   **Labels:** Use `label-md` floating above the field. Never hide labels inside the input.

### Navigation Sidebar
*   **Visuals:** Use `surface-container-low`. 
*   **Active State:** Do not use a "block" highlight. Use a soft `primary-container` pill shape that surrounds the icon and text, or a simple `primary` vertical notch on the far left.

---

## 6. Do's and Don'ts

### Do:
*   **Do** use "Breathing Room." If you think a section needs more padding, double it.
*   **Do** use the `tertiary` palette (teals/soft greens) for "Growth" or "New Member" indicators to provide a warm, organic contrast to the professional blue.
*   **Do** align text-heavy data to a strict baseline grid to maintain the "Editorial" feel.

### Don't:
*   **Don't** use 100% black (#000000) for text. Always use `on-surface` (#2e333a) to keep the interface soft on the eyes.
*   **Don't** use "Sharp" corners. Even the smallest component should have at least the `sm` (0.125rem) radius to feel "friendly."
*   **Don't** use "Standard" icons. Choose a light-weight, open-stroke icon set (2px stroke width) to match the Manrope typography.

---

## Final Director's Note
The users of this system are managing people, not just rows in a database. Every interaction should feel intentional and respectful. By removing the "clutter" of lines and boxes, we allow the congregation's data to breathe, making the administrative work feel less like a chore and more like a calling.